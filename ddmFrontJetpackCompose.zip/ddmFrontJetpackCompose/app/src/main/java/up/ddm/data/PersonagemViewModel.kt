package up.ddm.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class PersonagemViewModel(private val repository: PersonagemRepository) : ViewModel() {

    val allPersonagens: LiveData<List<up.ddm.Personagem>> = repository.allPersonagens

    fun insert(personagem: Personagem) = viewModelScope.launch {
        repository.insert(personagem)
    }

    fun update(personagem: Personagem) = viewModelScope.launch {
        repository.update(personagem)
    }

    fun delete(personagem: Personagem) = viewModelScope.launch {
        repository.delete(personagem)
    }
}
