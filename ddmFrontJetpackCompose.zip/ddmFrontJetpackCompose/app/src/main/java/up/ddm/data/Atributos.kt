package up.ddm

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "atributos")
data class Atributos(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,  // Chave primária de Atributos
    val forca: Int,
    val destreza: Int,
    val inteligencia: Int
)
