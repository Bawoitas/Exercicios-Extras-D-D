package up.ddm.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class AtributosViewModel(private val repository: AtributosRepository) : ViewModel() {

    val allAtributos: LiveData<List<up.ddm.Atributos>> = repository.allAtributos

    fun insert(atributos: Atributos) = viewModelScope.launch {
        repository.insert(atributos)
    }

    fun update(atributos: Atributos) = viewModelScope.launch {
        repository.update(atributos)
    }

    fun delete(atributos: Atributos) = viewModelScope.launch {
        repository.delete(atributos)
    }
}
