package up.ddm.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import up.ddm.Personagem

@Dao
interface PersonagemDAO {
    @Query("SELECT * FROM personagem")
    fun getAll(): LiveData<List<Personagem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(personagem: up.ddm.data.Personagem)

    @Update
    suspend fun update(personagem: up.ddm.data.Personagem)

    @Delete
    suspend fun delete(personagem: up.ddm.data.Personagem) // Método de deletar
}
