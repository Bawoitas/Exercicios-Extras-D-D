package up.ddm.data

import androidx.lifecycle.LiveData
import up.ddm.Atributos

class AtributosRepository(private val atributosDAO: AtributosDAO) {

    val allAtributos: LiveData<List<Atributos>> = atributosDAO.getAll()

    suspend fun insert(atributos: up.ddm.data.Atributos) {
        atributosDAO.insert(atributos)
    }

    suspend fun update(atributos: up.ddm.data.Atributos) {
        atributosDAO.update(atributos)
    }

    suspend fun delete(atributos: up.ddm.data.Atributos) {
        atributosDAO.delete(atributos)
    }
}
