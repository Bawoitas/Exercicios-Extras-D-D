package up.ddm.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import up.ddm.Atributos

@Dao
interface AtributosDAO {

    @Query("SELECT * FROM atributos")
    fun getAll(): LiveData<List<Atributos>> // Método para obter todos os atributos

    @Insert
    suspend fun insert(atributos: up.ddm.data.Atributos)

    @Update
    suspend fun update(atributos: up.ddm.data.Atributos)

    @Delete
    suspend fun delete(atributos: up.ddm.data.Atributos)
}
