package up.ddm.data

import androidx.lifecycle.LiveData

class PersonagemRepository(private val personagemDAO: PersonagemDAO) {

    val allPersonagens: LiveData<List<up.ddm.Personagem>> = personagemDAO.getAll()

    suspend fun insert(personagem: Personagem) {
        personagemDAO.insert(personagem)
    }

    suspend fun update(personagem: Personagem) {
        personagemDAO.update(personagem)
    }

    suspend fun delete(personagem: Personagem) {
        personagemDAO.delete(personagem)
    }
}
