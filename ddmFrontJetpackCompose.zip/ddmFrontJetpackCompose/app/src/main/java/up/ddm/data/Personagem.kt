package up.ddm

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "personagem")
data class Personagem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,  // Chave primária do personagem
    val nome: String,

    @Embedded(prefix = "atrib_") val atributos: Atributos  // Usando prefixo para evitar conflitos
)
